#include <iostream>
#include "dpll/dpll.h"
#include <time.h>
using namespace std;


int main(int argc, char * argv[]){
            clock_t t1,t2;
            t1=clock();

            DPLL dpll(argv[1]);

                if(argc < 2) {

                   cout<< "You must provide at least one argument" <<endl;

                   exit(0);

                 }


            cout << "No. of Clauses = " << dpll.getNbClauses() << endl;
            cout << "No. of literals = "<< dpll.getLits().size() << endl;
            if (dpll.hasSolution())
            {
             cout << "SATISFIABLE" << endl;
            }
           
           else
           {
             cout << "UNSATISFIABLE" << endl;
           }

           t2=clock();
           float diff ((float)t2-(float)t1);
           cout<< "Time in sec = " << diff/CLOCKS_PER_SEC<<endl;
           return 0;

}
