#include "clause.h"
#include <iostream>
#include <stdlib.h>
#include <math.h>
using namespace std;

Clause::Clause():
    num_lit()
{

}

Clause::Clause(int *literals, int lits):
    num_lit(lits)
{
    for (int i = 0; i < lits; ++i){
        num_lit[i] = literals[i];
    }
    sortLit();
}

Clause::Clause(vector<int> &literals):
    num_lit(literals)
{
    sortLit();
}

Clause::Clause(const Clause &c):
    num_lit(c.getNo())
{
    int lits = c.getNo();
    for (int i = 0; i < lits; ++i){
        num_lit[i] = c(i);
    }
    sortLit();
}

Clause::~Clause()
{

}

void Clause::sortLit()
{
    for (int i = 0; i < num_lit.size(); ++i)
    {
        for (int j = 0; j < num_lit.size() - i - 1; ++j)
        {
            if (abs(num_lit[j]) > abs(num_lit[j+1]))
            {
                int temp = num_lit[j];
                num_lit[j] = num_lit[j+1];
                num_lit[j+1] = temp;
            }

        }
    }
}
int Clause::getNo() const
{
    return num_lit.size();        // return number of lits
}

void Clause::addLit(int literal)
{
    num_lit.push_back(literal);   // add the literal to the end of the vector
}

int Clause::getLit(int i) const
{
    return num_lit[i];
}

int Clause::signLit(int literal) const
{
    for(int i =0; i < num_lit.size(); i++)
    {
        int currValue = num_lit[i];
        if (abs(currValue) == literal && currValue < 0)
        {
            return -1;   //negative
        }

        if (abs(currValue) == literal && currValue > 0)
        {
            return 1;        //posative
        }
        
        if (abs(currValue) > literal)
        {
            return 0;          // not defined
        }
       
    }
    return 0;
}


vector<int> Clause::getLits() const{
    vector<int> literals = num_lit;
    for (int i = 0; i < literals.size(); ++i)
        literals[i] = abs(literals[i]);
    return literals;
}

int  Clause::remove(int literal){

    vector<int> literals;
    for (int i = 0; i < num_lit.size(); ++i)
    {
         if (num_lit[i] == -literal)
        {
            continue;
        }
        if (num_lit[i] == literal)
        {
            return 1;
        }

        literals.push_back(num_lit[i]);
    }
    num_lit = literals;
    if (num_lit.size() == 0)
    {
        return -1;
    }
    return 0;
}

bool Clause::isUnit() const
{
    return (num_lit.size() == 1);
}



bool Clause::hasLit(int literal) const
{
    return signLit(literal) != 0;
}


int Clause::operator ()(const int i) const
{
    return num_lit[i];

}
