#ifndef DPLL_H
#define DPLL_H
#include <vector>
#include <ostream>
#include "clause.h"
using namespace std;

class DPLL{
    vector<Clause> mclause;

public:
    DPLL();      //default constructor 
    DPLL(Clause * c, int nClause);
    DPLL(vector<Clause> &c);
    DPLL(string pathToFile);
    DPLL(const DPLL &dpll);
    ~DPLL(); //destructor

    int getNbClauses() const;                     //return No. of clauses 
    void addClause(const Clause & c);            // add the current clause to the CNF formula
    Clause getClause(int i) const;              //get the clause
    void loadFile(string pathToFile); //parse the input file
    vector<int> getLits() const;     //get the literals 
    bool isPure(int) const;           //determine if a literal is a pure or not
    void validPure(int);              //determine if the current literal is valid pure or not
    bool remove(int literal);                //remove a literal from the clause
    bool unitPropagate();                 // remove unit clause
    bool removePure();               // remove pure literal
    bool hasSolution();                       //check if there is a solution to the problem or not
    Clause operator()(const int i) const;
    vector<int> add(vector<int> , vector<int> ) const;

};

#endif//DPLL_H

