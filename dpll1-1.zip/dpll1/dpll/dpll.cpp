#include "dpll.h"
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
using namespace std;


DPLL::DPLL():
    mclause()
{

}

DPLL::DPLL(string pathToFile)
{
    loadFile(pathToFile);
}


DPLL::DPLL(Clause *c, int nClause):
    mclause(nClause)
{
    for (int i = 0; i < nClause; ++i){
        mclause[i] = c[i];
    }
}

DPLL::DPLL(vector<Clause> &c):
    mclause(c)
{

}


DPLL::DPLL(const DPLL &dpll):
    mclause(dpll.getNbClauses())
{
    int nClause = mclause.size();
    for (int i = 0; i < nClause; ++i){
        mclause[i] = dpll(i);
    }

}

DPLL::~DPLL(){

}

int DPLL::getNbClauses() const
{
    return mclause.size();
}

void DPLL::addClause(const Clause &c)
{
    mclause.push_back(c);
}

Clause DPLL::getClause(int i) const
{
    return mclause[i];
}

void DPLL::loadFile(string pathToFile)
{
    ifstream file(pathToFile.c_str());

    if (!file){
        cerr << "No file found ";
        abort();
    }

    string currLine;
    while (getline(file, currLine)){
        if (currLine[0] == 'c' || currLine[0] == 'p')
        {
            continue;
        
        }
        else
        {
            stringstream asciiCause(currLine);
            Clause c;
            while(asciiCause.good())
            {
                int x;
                asciiCause >> x;
                if (x != 0)
                    c.addLit(x);
            }
            addClause(c);
        }

    }
}

vector<int> DPLL::getLits() const
{
    vector<int> literals;
    if (mclause.size() > 0) 
    {
        literals = mclause[0].getLits();
    }
    for (int i = 1; i < mclause.size(); ++i)
    {
        literals = add(literals, mclause[i].getLits());
    }
    return literals;
}

bool DPLL::isPure(int literal) const
{
    int temp1 = 0, temp2=0;
    for (int i = 0; i < mclause.size(); ++i)
    {
        if (temp1 == 0)
        {
            temp1 = mclause[i].signLit(literal);
        }
        else 
        {
            int temp2 = mclause[i].signLit(literal);
            if ( temp2 != 0 && temp2 != temp1)
            {
                return false;
            }
        }
    }
    return true;
}

void DPLL::validPure(int literal)
{
    vector<Clause> c;
    for (int i = 0; i < mclause.size(); ++i)
    {
        if (!(mclause[i].hasLit(literal)))
        {
            c.push_back(mclause[i]);
        }
    }
    mclause = c;
}

bool DPLL::remove(int literal)
{
    bool flag = true;
    int temp =0;
    vector<Clause> c;
    for (int i = 0; i < mclause.size(); ++i){
         temp = mclause[i].remove(literal);
        if (temp == 1)
        {
            continue;
        }
        c.push_back(mclause[i]);
        if (temp == -1)
        {
            flag= false;
        }
    }
    mclause = c;
    return flag;
}


bool DPLL::unitPropagate()
{
    bool flag = true;
    for (int i = 0; i < mclause.size(); ++i)
    {
        Clause * c = &(mclause[i]);
        if (c->isUnit())
        {
            int l = c->getLit(0);
            vector<Clause> c;
            for (int j = 0; j < mclause.size(); ++j)
            {
                if (j == i)
                    continue;
                int value = mclause[j].remove(l);
                if (value == -1)
                {
                    return false;
                }
                if (value != 1)
                {
                    c.push_back(mclause[j]);
                }
            }
            mclause = c;
            i = -1;
        }
    }
    return flag;
}

bool DPLL::removePure()
{
    vector<int> literals = getLits();
    int n = literals.size();
    for (int i = 0; i < n; ++i)
    {
        int l = literals[i];
        if (isPure(l))
        {
            validPure(l);
            return true;
        }
    }
    return false;
}

bool DPLL::hasSolution()
{
    do
    {
        while(removePure());
        if (!unitPropagate())
            return false;
    }
    while(removePure());
    if (mclause.size() == 0)
        return true;
    vector<int> literals = getLits();

    DPLL c1(*this);
    vector<int> clause; clause.push_back(literals[0]);
    c1.addClause(clause);
    if (c1.hasSolution())
        return true;
    DPLL c2(*this);
    clause[0] = -clause[0];
    c2.addClause(clause);
    return c2.hasSolution();
}

Clause DPLL::operator ()(const int i) const
{
    return getClause(i);
}

vector<int> DPLL::add(vector<int> v1, vector<int> v2) const
{
    vector<int> result;
    int i1 = 0; int i2 = 0;

    if (v1[i1] < v2[i2])
    {
        result.push_back(v1[i1++]);
    }
    else
    {
        result.push_back(v2[i2++]);
    }

    while (i1 < v1.size() || i2 < v2.size())
    {
        if (i1 == v1.size()){
            if (result[result.size() - 1] < v2[i2])
            {
                result.push_back(v2[i2]);
            }
            i2++;
        }
        else if (i2 == v2.size()){
            if (result[result.size() - 1] < v1[i1])
            {
                result.push_back(v1[i1]);
            }
            i1++;
        }
        else
        {
            if (v1[i1] < v2[i2])
            {
                if (result[result.size() - 1] < v1[i1])
                    result.push_back(v1[i1]);
                ++i1;
            }
            else
            {
                if(result[result.size() - 1] < v2[i2])
                    result.push_back(v2[i2]);
                ++i2;
            }
        }

    }
    return result;
}
