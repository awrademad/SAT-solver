#ifndef CLAUSE_H
#define CLAUSE_H
#include <vector>
#include <string>
using namespace std;




class Clause{
    vector<int> num_lit;

public:
    // Constructors
    Clause();
    Clause(int * literals, int nbLiterals);
    Clause(vector<int> & literals);
    Clause(const Clause & c);
    ~Clause();
    //methods 
    void sortLit();
    int getNo() const;       //find the number of lits
    void addLit(int);    //add literals
    int getLit(int) const;    //get literal
    int signLit(int) const;  // return the sign of literal
    vector<int> getLits() const;  // get the literals 
    int remove(int literal);               //remove literals
    bool isUnit() const;                   // determine if the clause has unit lit 
    bool hasLit(int) const;      //determine if there is a literal
    int operator()(const int) const;
};

#endif//CLAUSE_H
